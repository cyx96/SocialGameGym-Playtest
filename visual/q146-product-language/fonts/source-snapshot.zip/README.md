# SGG Paper UI 2.2 optical correction 2 · candidate

This local source package replays FL-01's explicit 日 lower-right closure in U+590D 复 against the exact adopted 2.1 input fonts. It does not recompile the repertoire or alter the shared compiler. Only 复's two solid outlines and name IDs3/5 change; 9701 other cmap glyphs, every glyph metric, cmap/order and the Logo remain exact.

Use an existing Python3 with FontTools4.67.0, skia-pathops0.9.2 and Brotli1.2.1:

`PYTHONDONTWRITEBYTECODE=1 python rebuild.py --out /a/new/output`

The script rejects an existing output and wrong input-font hashes, reconstructs the exact pre-correction glyph from fixed licensed source, freezes the original contact permissions, checks both stroke graphs for new third-stroke collisions and lost joins, and compares all9703 glyphs and full hmtx after serialization. Only the 日 wall/bottom pair[3,5] closes. Old unresolved pair[2,6] is deliberately left open to preserve the 日/夂 white gap.

`glyphs-used.json`, structures and original `contact-repairs.json` remain unchanged source records. The original1694 source-pair ledger is retained; new `optical-override.json`, `contact-result.json` and `unresolved-ledger-status.json` are additive correction records, not a claim of whole-library optical approval. The earlier 图 correction persists because the seeds are2.1. The complete previous2.1 source package remains in `previous-2.1-source-snapshot.zip`.

No network or font installation is required. Latin original/R8 heritage and APL source notices remain in the package; Hanzi medians/contact sources retain Arphic Public License and dictionary structure metadata retains LGPL-3.0-or-later. All original notices are preserved. This is an author candidate, not independently accepted or production adopted.
