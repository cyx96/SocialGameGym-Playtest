# SGG Paper UI 2.1 optical correction 1

Ordinary UI stays solid Text/Display. The declared repertoire remains9702 codepoints /9565 Hanzi, with all GB2312 Hanzi. Only U+56FE 图 changes its outline; all hmtx, cmap and glyph order remain exact. Internal name IDs3/5 now agree with2.1. The Logo is unchanged.

This source package contains the fixed licensed median/contact source, source compiler, APL and LGPL source notices, the exact2.0 input-font seeds and a portable local correction. With Python3, FontTools, skia-pathops and Brotli already available, run `python rebuild.py --out /new/path`. It refuses an existing output; comparison.json binds both input/output SHA and checks every glyph/metric. This replays the2.1 correction against the exact2.0 compiled seeds. The full common-family source compiler and fixed sources are also retained; upstream R8 generation remains the font studio workflow described in the manual.

The optical override deliberately separates the inner冬 diagonal from the enclosing囗, instead of restoring the source's contact [1,4]. No CSS coloring or text substitution implements this repair. Ordinary platform fallback is still used outside this fixed repertoire; no all-Unicode or all-glyph visual acceptance claim.

See the formal delivery font-optical-final-review.md for the independent finite reviewed scope.
