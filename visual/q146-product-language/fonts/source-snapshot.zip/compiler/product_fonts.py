#!/usr/bin/env python3
"""Compile solid product fonts from approved outlines and licensed Hanzi medians.

The unchanged approved color family is subset separately for the wordmark.
No network, arbitrary font tracing, or per-page typography is performed here.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import json
from math import hypot
import shutil
import unicodedata
import pathops
from fontTools.ttLib import TTFont
from fontTools import subset
from fontTools.pens.ttGlyphPen import TTGlyphPen
from hanzi_contacts import source_contacts,grid_contacts,restore_contacts

ROOT = Path(__file__).resolve().parents[1]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def corpus(product):
    """Conservative authored-text superset, including labels in code/attributes."""
    config=json.loads((product/'design/system/source/font-corpus.json').read_text())
    files = sorted({p for root in config['roots'] for p in (product/root).rglob('*')
                    if p.is_file() and p.suffix in set(config['extensions'])})
    chars = set()
    records = {}
    for p in files:
        # Manifest/provenance contain paths and hashes, not player text. Excluding
        # font source keeps subsequent generation independent of its own output.
        if '/fonts/' in p.as_posix():
            continue
        chars.update(p.read_text())
        records[str(p.relative_to(product))] = digest(p)
    chars = {c for c in chars if not unicodedata.category(c).startswith('C')}
    return chars, records

def rdp(points, epsilon=3.2):
    if len(points)<3:
        return points
    a,b=points[0],points[-1]
    dx,dy=b[0]-a[0],b[1]-a[1]
    length=hypot(dx,dy)
    distances=[abs(dy*(p[0]-a[0])-dx*(p[1]-a[1]))/length if length else hypot(p[0]-a[0],p[1]-a[1]) for p in points[1:-1]]
    maximum=max(distances)
    if maximum<=epsilon:
        return [a,b]
    i=distances.index(maximum)+1
    return rdp(points[:i+1],epsilon)[:-1]+rdp(points[i:],epsilon)

def regularize(points):
    """Fit shallow calligraphic slants to shared paper-fold axes, bounded at 4 units."""
    original=list(points)
    result=list(points)
    for _ in range(12):
        suggestions=[[p] for p in result]
        for i,(a,b) in enumerate(zip(result,result[1:])):
            dx,dy=b[0]-a[0],b[1]-a[1]
            if abs(dx)>abs(dy)*2:
                y=(a[1]+b[1])/2
                suggestions[i].append((a[0],y));suggestions[i+1].append((b[0],y))
            elif abs(dy)>abs(dx)*2:
                x=(a[0]+b[0])/2
                suggestions[i].append((x,a[1]));suggestions[i+1].append((x,b[1]))
        result=[(max(o[0]-4,min(o[0]+4,sum(x for x,y in group)/len(group))),
                 max(o[1]-4,min(o[1]+4,sum(y for x,y in group)/len(group))))
                for o,group in zip(original,suggestions)]
    return result

def median_lines(medians):
    result=[]
    for median in medians:
        points=regularize(rdp([(x/10.24,(900-y)/10.24) for x,y in median]))
        clean=[points[0]]
        for p in points[1:]:
            if hypot(p[0]-clean[-1][0],p[1]-clean[-1][1])>=.9:
                clean.append(p)
        if len(clean)==1:
            clean.append((clean[0][0]+1.5,clean[0][1]))
        # Very short backwards hooks are separate ribbons; bounded mitres below
        # prevent the almost opposite tangent from creating a long spike.
        result.append(clean)
    points=[p for line in result for p in line]
    if not points:
        raise ValueError('Empty Hanzi median source')
    xmin,xmax=min(x for x,y in points),max(x for x,y in points)
    ymin,ymax=min(y for x,y in points),max(y for x,y in points)
    sx,sy=min(1.2,80/max(1,xmax-xmin)),min(1.2,80/max(1,ymax-ymin))
    return [[(50+(x-(xmin+xmax)/2)*sx,50+(y-(ymin+ymax)/2)*sy) for x,y in line] for line in result]

def optical_widths(lines,base,style):
    """Keep white channels between close parallel strokes in dense components.

    Shared geometric rule, not per-character shading or a CSS substitution.
    Only long overlapping axis-aligned segments constrain each stroke's width.
    """
    widths=[base]*len(lines);segments=[]
    for i,line in enumerate(lines):
        for a,b in zip(line,line[1:]):
            dx,dy=abs(b[0]-a[0]),abs(b[1]-a[1])
            if dx>=dy*8 and dx>=5:segments.append((i,0,min(a[0],b[0]),max(a[0],b[0]),(a[1]+b[1])/2))
            elif dy>=dx*8 and dy>=5:segments.append((i,1,min(a[1],b[1]),max(a[1],b[1]),(a[0]+b[0])/2))
    ratio=.58 if style=='Text'else .66
    for i,axis,a,b,p in segments:
        for j,other,c,d,q in segments:
            if j<=i or axis!=other:continue
            overlap=min(b,d)-max(a,c);gap=abs(p-q)
            if overlap>=min(b-a,d-c)*.70 and gap>=1.5:
                cap=max(1.5,gap*ratio)
                widths[i]=min(widths[i],cap);widths[j]=min(widths[j],cap)
    return widths

def strip_contours(points,width):
    closed=points[0]==points[-1]
    ps=points[:-1] if closed else points
    normals=[]
    for a,b in zip(points,points[1:]):
        dx,dy=b[0]-a[0],b[1]-a[1]
        length=hypot(dx,dy)
        if length==0:
            raise ValueError('Duplicate ribbon station')
        normals.append((-dy/length,dx/length))
    offsets=[]
    for i in range(len(ps)):
        if i==0 and not closed:
            x,y=normals[0]
        elif i==len(ps)-1 and not closed:
            x,y=normals[-1]
        else:
            a,b=normals[i-1],normals[i%len(normals)]
            denominator=max(.32,1+a[0]*b[0]+a[1]*b[1])
            x,y=(a[0]+b[0])/denominator,(a[1]+b[1])/denominator
            length=hypot(x,y)
            if length>2:
                x,y=x*2/length,y*2/length
        offsets.append((x*width/2,y*width/2))
    left=[(x+o[0],y+o[1]) for (x,y),o in zip(ps,offsets)]
    right=list(reversed([(x-o[0],y-o[1]) for (x,y),o in zip(ps,offsets)]))
    return [left,right] if closed else [left+right]

def ribbon_union(lines,width):
    union=pathops.Path()
    for index,line in enumerate(lines):
        stroke_width=width[index]if isinstance(width,(list,tuple))else width
        part=pathops.Path()
        for i,contour in enumerate(strip_contours(line,stroke_width)):
            points=[(round(x*9.3+35),round(930-y*9.8)) for x,y in contour]
            area=sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(points,points[1:]+points[:1]))
            if (area>0)!=(i==1):
                points.reverse()
            part.moveTo(*points[0])
            for p in points[1:]:
                part.lineTo(*p)
            part.close()
        # Counters are resolved within a ribbon before union with other strokes.
        union=pathops.op(union,pathops.simplify(part),pathops.PathOp.UNION)
    return union

def symbol_lines():
    def line(*coords):
        return list(zip(coords[::2],coords[1::2]))
    s={
        '•':[line(22,49,22,56)],
        '\u202f':[], '\u00a0':[],
        '*':[line(27,12,27,50),line(9,21,45,41),line(9,41,45,21)],
        '@':[[((x-10),(y-20)*80/58+12) for x,y in line(52,78,28,78,14,64,14,34,28,20,50,20,63,33,63,57,56,64,49,64,44,59,44,33,27,33,21,39,21,55,27,61,37,61,44,54)]],
        '#':[line(31,12,18,89),line(65,12,52,89),line(10,39,76,39),line(6,63,72,63)],
        '&':[line(70,89,17,42,17,25,29,13,44,13,56,25,56,40,17,65,10,76,21,89,41,89,69,60)],
        '[':[line(36,12,14,12,14,94,36,94)],']':[line(12,12,34,12,34,94,12,94)],
        '{':[line(40,10,25,10,18,21,18,43,8,53,18,63,18,85,25,96,40,96)],
        '}':[line(10,10,25,10,32,21,32,43,42,53,32,63,32,85,25,96,10,96)],
        '<':[line(52,25,10,53,52,81)],'>':[line(10,25,52,53,10,81)],
        '=':[line(8,42,56,42),line(8,65,56,65)],'_':[line(3,98,64,98)],
        '\\':[line(9,12,48,96)],'|':[line(18,9,18,98)],'^':[line(9,37,32,12,55,37)],
        '~':[line(7,57,19,47,30,47,42,57,54,57,66,47)],
        '$':[line(61,25,50,14,24,14,11,27,11,41,24,53,48,53,61,65,61,77,49,89,23,89,10,78),line(36,3,36,101)],
        '"':[line(12,12,12,30),line(32,12,32,30)],'`':[line(12,10,23,24)],
        '…':[line(12,83,12,89),line(32,83,32,89),line(52,83,52,89)],
        '↗':[line(10,88,84,14),line(38,14,84,14,84,60)],
        '→':[line(8,53,88,53),line(66,31,88,53,66,75)],
        '≈':[line(8,43,21,36,35,36,49,44,63,44,76,37),line(8,65,21,58,35,58,49,66,63,66,76,59)],
        '≥':[line(14,22,68,48,14,74),line(12,88,70,88)],
        '、':[line(14,74,31,91)],'「':[line(38,12,14,12,14,69)],'」':[line(12,37,36,37,36,94)],
    }
    base=json.loads((ROOT/'source/lettering-centerlines.json').read_text())
    for new,old in [('（','('),('）',')'),('＋','+'),('／','/'),('；',';'),('＝','='),('–','−')]:
        s[new]=(base|s)[old]
    for new,old in zip('⁰¹²³⁴⁵⁶⁷⁸⁹','0123456789'):
        s[new]=[[(x*.64,y*.64-3) for x,y in path] for path in base[old]]
    s['⁻']=[line(5,28,40,28)]
    s['×']=[line(10,28,60,80),line(60,28,10,80)]
    s['½']=[[(x*.45,y*.45) for x,y in path] for path in base['1']]+[line(63,12,14,94)]+[[(x*.45+48,y*.45+48) for x,y in path] for path in base['2']]
    return s

def require_coverage(required,available):
    missing=sorted(set(required)-set(available))
    if missing:
        raise ValueError('Missing static characters: '+''.join(missing))

def set_names(font,family,style):
    font['name'].names=[n for n in font['name'].names if n.nameID not in {1,2,3,4,6,16,17}]
    names={1:family,2:style,3:family+'-'+style+'-product-v1',4:family+' '+style,6:family.replace(' ','')+'-'+style,16:family,17:style}
    for key,value in names.items():
        font['name'].setName(value,key,3,1,0x409)


def build(product,graphics,out,extra_roots=(),all_source_hanzi=False,dictionary=None):
    if out.exists():
        raise ValueError('Output already exists: '+str(out))
    required,sources=corpus(product)
    extra_records={}
    for root in extra_roots:
        files=sorted(p for p in root.rglob('*') if p.is_file() and p.suffix in {'.html','.js'} and not any(t in p.parts for t in ['evidence','review']))
        for p in files:
            required.update(c for c in p.read_text() if not unicodedata.category(c).startswith('C'))
            extra_records[str(p)]=digest(p)
    baseline=ROOT/'baseline/fonts'
    seeds={style:TTFont(baseline/f'SGGPaperVolume-{style}.woff2',recalcTimestamp=False) for style in ['Text','Display']}
    inherited=set(map(chr,seeds['Text'].getBestCmap()))
    symbols=symbol_lines()
    all_medians={}
    all_strokes={}
    source_provenance={}
    if graphics.suffix=='.json':
        loaded=json.loads(graphics.read_text())
        if loaded.get('schema')!=2:raise ValueError('Contact-aware generation requires glyphs-used.json schema 2 or full graphics + dictionary')
        source_provenance=loaded.get('upstream',{})
        all_medians={c:r['medians']for c,r in loaded['glyphs'].items()}
        all_contacts={c:r['contacts']for c,r in loaded['glyphs'].items()}
        semantic_contacts={c:r.get('gridContacts',[])for c,r in loaded['glyphs'].items()}
    else:
        if dictionary is None:raise ValueError('Full graphics input requires pinned --dictionary for semantic counter recipes')
        metadata={r['character']:r for r in map(json.loads,dictionary.open())}
        all_contacts={};semantic_contacts={}
        for raw in graphics.open():
            row=json.loads(raw);all_medians[row['character']]=row['medians'];all_strokes[row['character']]=row['strokes']
    repertoire={c for c in all_medians if '\u3400'<=c<='\u9fff'} if all_source_hanzi else set()
    required.update(repertoire)
    needed=required-inherited-set(symbols)
    medians={c:v for c,v in all_medians.items() if c in needed}
    require_coverage(required,inherited|set(symbols)|set(medians))
    out.mkdir(parents=True)
    (out/'fonts').mkdir()
    # Preserve a compact, redistributable source subset, not a network dependency.
    (out/'medians-used.json').write_text(json.dumps(medians,ensure_ascii=False,indent=2)+'\n')
    (out/'symbols.json').write_text(json.dumps(symbols,ensure_ascii=False,indent=2)+'\n')
    contact_repairs={};source_glyphs={};paths={};stroke_widths={}
    for c,v in medians.items():
        lines=median_lines(v)
        contacts=source_contacts(all_strokes[c]) if c in all_strokes else all_contacts[c]
        grids=grid_contacts(c,metadata) if c in all_strokes else semantic_contacts[c]
        source_glyphs[c]={'medians':v,'contacts':contacts,'gridContacts':grids}
        thinning=min(1.5,max(0,len(lines)-12)*.16)
        widths=[optical_widths(lines,base-thinning,style)for style,base in [('Text',6.6),('Display',7.8)]]
        stroke_widths[c]=dict(zip(['Text','Display'],widths))
        lines,report=restore_contacts(lines,contacts+grids,ribbon_union,widths,grid_pairs=grids)
        contact_repairs[c]=report;paths[c]=lines
    (out/'glyphs-used.json').write_text(json.dumps({'schema':2,'upstream':source_provenance or {'url':'https://github.com/skishore/makemeahanzi/tree/bddc96d41bef78427ed0e034e9f7e31d71fd1b92','graphicsSha256':digest(graphics),'license':'Arphic Public License','dictionarySha256':digest(dictionary),'dictionaryUrl':'https://github.com/skishore/makemeahanzi/blob/bddc96d41bef78427ed0e034e9f7e31d71fd1b92/dictionary.txt','dictionaryLicense':'LGPL-3.0-or-later'},'glyphs':source_glyphs},ensure_ascii=False)+'\n')
    (out/'contact-repairs.json').write_text(json.dumps(contact_repairs,ensure_ascii=False,indent=2)+'\n')
    paths.update({c:v for c,v in symbols.items() if c not in inherited and c in required})
    reports=[]
    for style,font in seeds.items():
        before={c:font['glyf'][n].compile(font['glyf']).hex() for c,n in font.getBestCmap().items()}
        # Strip all palette tables. Browser CSS color owns ordinary text.
        for table in ['COLR','CPAL']:
            del font[table]
        order=font.getGlyphOrder()
        for c,lines in sorted(paths.items()):
            name='u%04X'%ord(c)
            chinese='\u3400'<=c<='\u9fff'
            width=(7.8 if style=='Display' else 6.6)-min(1.5,max(0,len(lines)-12)*.16) if chinese else (10.2 if style=='Display' else 8.6)
            if chinese:width=stroke_widths[c][style]
            if c=='@':width*=.82
            pen=TTGlyphPen(None)
            ribbon_union(lines,width).draw(pen)
            glyph=pen.glyph()
            font['glyf'][name]=glyph
            advance=160 if c=='\u202f' else 300 if c=='\u00a0' else 1000 if chinese or c in '（）＋／；＝「」、' else 700
            if c=='@':advance=660
            if not chinese and lines and c not in '（）＋／；＝「」、':advance=max(advance,max(p[0] for p in glyph.coordinates)+35)
            font['hmtx'][name]=(advance,min((p[0] for p in getattr(glyph,'coordinates',[])),default=0))
            if name not in order:
                order.append(name)
            for t in font['cmap'].tables:
                if t.isUnicode():
                    t.cmap[ord(c)]=name
        font.setGlyphOrder(order)
        font['maxp'].numGlyphs=len(order)
        # Drop orphaned decorative glyphs without changing inherited base outlines.
        opts=subset.Options();opts.recalc_timestamp=False
        sub=subset.Subsetter(options=opts);sub.populate(unicodes=list(font.getBestCmap()));sub.subset(font)
        set_names(font,'SGG Paper UI',style)
        font.flavor='woff2'
        target=out/'fonts'/f'SGGPaperUI-{style}.woff2'
        font.save(target)
        exported=TTFont(target)
        require_coverage(required,set(map(chr,exported.getBestCmap())))
        changed=[chr(cp) for cp,raw in before.items() if exported['glyf'][exported.getBestCmap()[cp]].compile(exported['glyf']).hex()!=raw]
        if changed:
            raise ValueError('Inherited R8 outline drift: '+''.join(changed))
        assert 'COLR' not in exported and 'CPAL' not in exported
        reports.append({'style':style,'file':target.name,'sha256':digest(target),'characters':len(exported.getBestCmap()),'inheritedOutlinesUnchanged':True,'colorTables':False})
    # Logo subset retains its exact outlines, layer ordering and 24 theme palettes.
    logo=TTFont(baseline/'SGGPaperVolume-Display.woff2',recalcTimestamp=False)
    opts=subset.Options();opts.recalc_timestamp=False
    sub=subset.Subsetter(options=opts);sub.populate(text='SocialGameGym');sub.subset(logo)
    set_names(logo,'SGG Paper Logo','Display')
    logo.flavor='woff2';logo.save(out/'fonts/SGGPaperLogo.woff2')
    reference=TTFont(baseline/'SGGPaperVolume-Display.woff2')
    for cp,name in logo.getBestCmap().items():
        original=reference.getBestCmap()[cp]
        assert logo['hmtx'][name]==reference['hmtx'][original]
        assert logo['glyf'][name].compile(logo['glyf'])==reference['glyf'][original].compile(reference['glyf'])
        old,new=reference['COLR'].ColorLayers[original],logo['COLR'].ColorLayers[name]
        assert len(old)==len(new)
        for a,b in zip(old,new):
            assert reference['glyf'][a.name].compile(reference['glyf'])==logo['glyf'][b.name].compile(logo['glyf'])
            for old_palette,new_palette in zip(reference['CPAL'].palettes,logo['CPAL'].palettes):
                assert old_palette[a.colorID]==new_palette[b.colorID]
    for name in ['ARPHICPL.TXT']:
        shutil.copy2(ROOT/'source'/name,out/'fonts'/name)
    manifest={'schema':1,'sourceRoots':json.loads((product/'design/system/source/font-corpus.json').read_text())['roots'],'sourceFiles':sources,'requiredCharacters':sorted(required),'requiredCount':len(required),'hanziCount':sum('\u3400'<=c<='\u9fff' for c in required),'fonts':reports,'logo':{'file':'SGGPaperLogo.woff2','sha256':digest(out/'fonts/SGGPaperLogo.woff2'),'palettes':len(logo['CPAL'].palettes),'baselineRenderingUnchanged':True},'upstream':{'url':'https://github.com/skishore/makemeahanzi/tree/bddc96d41bef78427ed0e034e9f7e31d71fd1b92','graphicsSha256':digest(graphics),'license':'Arphic Public License'},'fallback':'Characters outside this authored corpus use the documented platform system font; emoji use native emoji fonts. No full-CJK claim.'}
    manifest['input']={'kind':'schema2-glyph-snapshot'if graphics.suffix=='.json'else'full-graphics-and-dictionary','sha256':digest(graphics)}
    if source_provenance:manifest['upstream']=source_provenance
    manifest['repertoire']={'policy':'all fixed-source CJK plus authored product and registered specimens','hanzi':manifest['hanziCount'],'generatedHanzi':len(medians),'gb2312Covered':all(c in set(map(chr,exported.getBestCmap())) for c in [bytes([a,b]).decode('gb2312') for a in range(0xb0,0xf8) for b in range(0xa1,0xff) if not (a==0xd7 and b>=0xfa)])}
    manifest['supplementalSourceFiles']=extra_records
    manifest['contactPolicy']={'version':5,'source':'original stroke intersections plus explicit recursively IDS-matched boxed-counter recipes','opticalWidthPolicy':'per-stroke parallel white-channel cap, Text .58 / Display .66, minimum 1.5 units','collisionGuard':'frozen per-family source/recipe and initial-rendered permissions; every candidate and final graph checked','maxEndpointExtension':12,'semanticGridBarLimit':16,'sourceSnapshot':'glyphs-used.json','snapshotSha256':digest(out/'glyphs-used.json'),'dictionarySha256':digest(dictionary) if dictionary else source_provenance.get('dictionarySha256'),'unresolvedPairs':sum(len(r['unresolved'])for r in contact_repairs.values()),'unpermittedCollisions':0}
    manifest['fallback']='Outside the declared fixed-source Hanzi and symbols, use documented platform fallback; no all-Unicode claim.'
    (out/'coverage.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({key:manifest[key] for key in ['requiredCount','hanziCount','fonts','logo']},ensure_ascii=False))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--product-root',required=True,type=Path)
    parser.add_argument('--graphics',required=True,type=Path)
    parser.add_argument('--out',required=True,type=Path)
    parser.add_argument('--extra-source-root',action='append',type=Path,default=[])
    parser.add_argument('--all-source-hanzi',action='store_true')
    parser.add_argument('--dictionary',type=Path)
    args=parser.parse_args()
    build(args.product_root.resolve(),args.graphics.resolve(),args.out.resolve(),args.extra_source_root,args.all_source_hanzi,args.dictionary)
