"""Bounded endpoint restoration with frozen per-family collision permissions."""
from math import hypot
import pathops
from fontTools.svgLib.path import parse_path

def source_contacts(strokes):
    shapes=[]
    for s in strokes:
        p=pathops.Path();parse_path(s,p.getPen());shapes.append(pathops.simplify(p))
    return [(j,i) for i in range(len(shapes)) for j in range(i)
            if pathops.op(shapes[i],shapes[j],pathops.PathOp.INTERSECTION).area>1]

def grid_contacts(character,metadata):
    """Resolve boxed-counter recipes through exact, recursively matched IDS strokes.

    A component is expanded only when its known stroke count exactly matches
    the assigned parent strokes. No enclosure or nearest-neighbour guessing.
    """
    recipes={'田':(5,[0,1],[2]),'日':(4,[0,1],[2]),'目':(5,[0,1],[2,3]),'甲':(5,[0,1],[2,3]),'申':(5,[0,1],[2,3]),'由':(5,[0,1],[2,4]),'里':(7,[0,1],[2,3]),'单':(8,[2,3],[4,5])}
    pairs=set()
    def expand(c,indices,ancestors):
        if c in ancestors or len(ancestors)>10 or c not in metadata:return
        row=metadata[c]
        if len(indices)!=len(row['matches']):return
        if c in recipes:
            count,sides,bars=recipes[c]
            if len(indices)==count:
                for bar in bars:
                    for side in sides:pairs.add(tuple(sorted((indices[side],indices[bar]))))
        decomp=iter(row['decomposition'])
        def visit(path):
            try:part=next(decomp)
            except StopIteration:return
            if '\u2ff0'<=part<='\u2ffb':
                for i in range(3 if part in '⿲⿳' else 2):visit(path+[i])
            else:
                assigned=[indices[i]for i,m in enumerate(row['matches'])if m is not None and m[:len(path)]==path]
                expand(part,assigned,ancestors|{c})
        visit([])
    if character in metadata:expand(character,list(range(len(metadata[character]['matches']))),set())
    return sorted(pairs)

def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def subtract(a,b):return a[0]-b[0],a[1]-b[1]
def intersects(a,b):return pathops.op(a,b,pathops.PathOp.INTERSECTION).area>1

def restore_contacts(lines,contacts,render,widths,limit=12,grid_pairs=()):
    lines=[[tuple(p)for p in line]for line in lines]
    originals=[[p for p in line]for line in lines]
    contacts=sorted(set(tuple(sorted(p))for p in contacts))
    def stroke_shape(line,metrics,index):return render([line],metrics[index]if isinstance(metrics,(list,tuple))else metrics)
    shapes=[[stroke_shape(line,width,index)for index,line in enumerate(lines)]for width in widths]
    # Permissions are frozen before ANY modification, not expanded by a repair.
    allowed=[set(contacts)|{(j,i)for i in range(len(lines))for j in range(i)if intersects(ss[i],ss[j])}for ss in shapes]
    repairs=[];rejected=0
    grid_pairs={tuple(sorted(p))for p in grid_pairs}
    for _ in range(2):
        changed=False
        for i,j in contacts:
            pair_limit=16 if (i,j) in grid_pairs else limit
            if all(intersects(ss[i],ss[j])for ss in shapes):continue
            candidates=[]
            for a,b in [(i,j),(j,i)]:
                for endpoint,adjacent in [(0,1),(-1,-2)]:
                    p=lines[a][endpoint];v=subtract(p,lines[a][adjacent]);length=hypot(*v)
                    if length<1e-6:continue
                    v=v[0]/length,v[1]/length
                    for q,r in zip(lines[b],lines[b][1:]):
                        w=subtract(r,q);den=cross(v,w)
                        if abs(den)<1e-7:continue
                        qp=subtract(q,p);t=cross(qp,w)/den;u=cross(qp,v)/den
                        if .001<t<=pair_limit and -.001<=u<=1.001:
                            target=p[0]+t*v[0],p[1]+t*v[1]
                            if hypot(*subtract(target,originals[a][endpoint]))<=pair_limit:
                                candidates.append((t,[(a,endpoint,target,t)]))
            # Two terminal rays can meet just beyond both finite strokes (e.g.
            # the top-left corner of 困). Both stay on their own original axes.
            for ae,aa in [(0,1),(-1,-2)]:
                p=lines[i][ae];v=subtract(p,lines[i][aa]);vl=hypot(*v)
                if vl<1e-6:continue
                v=v[0]/vl,v[1]/vl
                for be,ba in [(0,1),(-1,-2)]:
                    q=lines[j][be];w=subtract(q,lines[j][ba]);wl=hypot(*w)
                    if wl<1e-6:continue
                    w=w[0]/wl,w[1]/wl;den=cross(v,w)
                    if abs(den)<1e-7:continue
                    qp=subtract(q,p);t=cross(qp,w)/den;u=cross(qp,v)/den
                    if 0<t<=pair_limit and 0<u<=pair_limit:
                        target=(p[0]+t*v[0],p[1]+t*v[1])
                        if all(hypot(*subtract(target,originals[a][e]))<=pair_limit for a,e in [(i,ae),(j,be)]):
                            candidates.append((t+u,[(i,ae,target,t),(j,be,target,u)]))
            for cost,changes in sorted(candidates,key=lambda c:c[0]):
                proposed={a:list(lines[a])for a,e,target,t in changes}
                for a,e,target,t in changes:proposed[a][e]=target
                next_shapes=[list(ss)for ss in shapes]
                for ss,width in zip(next_shapes,widths):
                    for a,line in proposed.items():ss[a]=stroke_shape(line,width,a)
                if not all(intersects(ss[i],ss[j])for ss in next_shapes):continue
                if any(intersects(ss[a],ss[k])for ss,permit in zip(next_shapes,allowed)
                       for a in proposed for k in range(len(lines))if k!=a and tuple(sorted((a,k)))not in permit):
                    rejected+=1;continue
                for a,line in proposed.items():lines[a]=line
                shapes=next_shapes
                for a,e,target,t in changes:
                    repairs.append({'pair':[i,j],'stroke':a,'endpoint':e,'extension':round(t,4)})
                changed=True;break
        if not changed:break
    unresolved=[{'pair':[i,j],'families':[s for s,ss in zip(['Text','Display'],shapes)if not intersects(ss[i],ss[j])]}for i,j in contacts if not all(intersects(ss[i],ss[j])for ss in shapes)]
    collisions=[(f,j,i)for f,ss,permit in zip(['Text','Display'],shapes,allowed)for i in range(len(lines))for j in range(i)if (j,i)not in permit and intersects(ss[i],ss[j])]
    if collisions:raise ValueError('Unpermitted third-stroke collision: '+repr(collisions))
    return lines,{'repairs':repairs,'rejectedUnsafeCandidates':rejected,'unresolved':unresolved,'unpermittedCollisions':0}
