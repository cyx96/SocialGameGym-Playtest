"""Replay one explicit 日-component optical correction against exact 2.1 seeds.

No whole-repertoire rebuild and no shared compiler changes.
"""
from pathlib import Path
import argparse,copy,hashlib,json,sys,shutil,importlib.metadata
from fontTools.ttLib import TTFont
from fontTools.pens.ttGlyphPen import TTGlyphPen
source=Path(__file__).resolve().parent
sys.path.insert(0,str(source/'compiler'))
from product_fonts import median_lines,optical_widths,ribbon_union
from hanzi_contacts import restore_contacts,intersects

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',required=True,type=Path);args=parser.parse_args();out=args.out.resolve()
    if out.exists():raise SystemExit('Choose a new output directory')
    out.mkdir(parents=True);(out/'fonts').mkdir()
    inputs={'Text':'39721a2936c2969d857e70bde0a47674f7db1f80fdc0ff3d591fc94452e03e2d','Display':'93c6f03dc31c2fa67110f04703a70004770b2ff244953a2c56e5a1edeb03c14e'}
    assert sha(source/'input-fonts/SGGPaperLogo.woff2')=='b441184c100b67e0812c45ccb4fc69f7c0a36b59ad9f6277cdf1a009553b186e'
    row=json.loads((source/'glyphs-used.json').read_text())['glyphs']['复']
    lines=median_lines(row['medians'])
    widths=[optical_widths(lines,b,s)for s,b in [('Text',6.6),('Display',7.8)]]
    original,prior=restore_contacts(lines,row['contacts']+row['gridContacts'],ribbon_union,widths,grid_pairs=row['gridContacts'])
    # stroke3 is 日's top/right wall. Its short left return hook was above
    # stroke5's bottom bar. Connect the two at the wall's existing x axis,
    # preserving every other normalized station and all original optical widths.
    repaired=copy.deepcopy(original)
    corner=(original[3][-2][0],original[5][-1][1])
    repaired[3]=original[3][:-2]+[corner]
    repaired[5][-1]=corner
    assert [i for i in range(len(original))if original[i]!=repaired[i]]==[3,5]
    changes={'finding':'FL-01','character':'复','sourcePair':[3,5],'semanticComponent':'日 at IDS path [1,0], source strokes 2/3/4/5 (zero-based)',
             'method':'Replace only right-wall return hook by straight wall ending at existing bottom-bar y; extend bottom bar to the same corner. No shared rule or optical width change.',
             'originalLines':original,'correctedLines':repaired,'corner':corner,'widths':dict(zip(['Text','Display'],widths)),'priorContactResult':prior}
    write(out/'optical-override.json',changes)
    checks={};comparison={}
    for style,width in zip(['Text','Display'],widths):
        seed=source/'input-fonts'/f'SGGPaperUI-{style}.woff2';assert sha(seed)==inputs[style]
        font=TTFont(seed,recalcTimestamp=False);cmap=font.getBestCmap();name=cmap[ord('复')]
        before={n:font['glyf'][n].compile(font['glyf'])for n in font.getGlyphOrder()};metrics=copy.deepcopy(font['hmtx'].metrics);order=font.getGlyphOrder()
        # Reconstruct the exact original 复 before changing it. This protects
        # against attributing today's algorithm or a wrong source to the seed.
        baselinePen=TTGlyphPen(None);ribbon_union(original,width).draw(baselinePen)
        assert baselinePen.glyph().compile(font['glyf'])==before[name],style+' source does not reproduce 2.1 复'
        oldShapes=[ribbon_union([line],width[i])for i,line in enumerate(original)]
        newShapes=[ribbon_union([line],width[i])for i,line in enumerate(repaired)]
        oldEdges={(j,i)for i in range(len(original))for j in range(i)if intersects(oldShapes[j],oldShapes[i])}
        newEdges={(j,i)for i in range(len(original))for j in range(i)if intersects(newShapes[j],newShapes[i])}
        permitted=oldEdges|{tuple(sorted(p))for p in row['contacts']+row['gridContacts']}
        assert (3,5)not in oldEdges and (3,5)in newEdges,style+' lower 日 corner not repaired'
        assert not newEdges-permitted,('new third-stroke collision',style,newEdges-permitted)
        assert not oldEdges-newEdges,('lost established join',style,oldEdges-newEdges)
        assert (2,6)not in newEdges,'Preserve separate 日 / 夂 white gap'
        checks[style]={'pair35':{'before':False,'after':True},'newContacts':[list(p)for p in sorted(newEdges-oldEdges)],'lostContacts':[],'unpermittedCollisions':0,'pair26StillOpen':True}
        pen=TTGlyphPen(None);ribbon_union(repaired,width).draw(pen);font['glyf'][name]=pen.glyph()
        for key,value in {3:f'SGG Paper UI-{style}-product-2.2',5:'Version 2.200; common Hanzi optical correction 2'}.items():
            font['name'].names=[n for n in font['name'].names if n.nameID!=key];font['name'].setName(value,key,3,1,0x409)
        target=out/'fonts'/seed.name;font.save(target);actual=TTFont(target,recalcTimestamp=False)
        changed=[n for n in order if actual['glyf'][n].compile(actual['glyf'])!=before[n]]
        assert changed==[name],changed
        assert actual['hmtx'].metrics==metrics and actual.getBestCmap()==cmap and actual.getGlyphOrder()==order
        assert len(cmap)==9702 and 'COLR'not in actual and 'CPAL'not in actual
        comparison[style]={'inputSha256':sha(seed),'outputSha256':sha(target),'changedGlyphs':['复'],'changedGlyphNames':changed,'unchangedCmapGlyphs':9701,'allGlyphsCompared':len(order),'cmapUnchanged':True,'glyphOrderUnchanged':True,'allMetricsUnchanged':True,'colorTables':False,'allowedNameChanges':[3,5]}
    shutil.copyfile(source/'input-fonts/SGGPaperLogo.woff2',out/'fonts/SGGPaperLogo.woff2')
    shutil.copyfile(source/'ARPHICPL.TXT',out/'fonts/ARPHICPL.TXT')
    comparison['Logo']={'sha256':sha(out/'fonts/SGGPaperLogo.woff2'),'bytesUnchanged':True}
    write(out/'comparison.json',comparison);write(out/'contact-result.json',checks)
    # Preserve the original 1694-pair ledger; the optical exception is a separate
    # additive decision, never a silent rewrite of historical unresolved source.
    for n in ['glyphs-used.json','contact-repairs.json','symbols.json']:shutil.copyfile(source/n,out/n)
    ledger=json.loads((source/'contact-repairs.json').read_text());assert sum(len(v['unresolved'])for v in ledger.values())==1694
    write(out/'unresolved-ledger-status.json',{'sourceLedgerSha256':sha(source/'contact-repairs.json'),'sourcePairsRetained':1694,'sourceEntriesRetained':len(ledger),'opticalExceptions':[{'character':'复','pair':[3,5],'families':['Text','Display'],'status':'mechanically joined; visual review pending' }],'pair26':'retained unresolved; preserve 日/夂 gap','noClaim':'Not all source pairs are visible defects; no whole-repertoire visual acceptance.'})
    coverage=json.loads((source/'input-coverage.json').read_text())
    for r in coverage['fonts']:r['sha256']=comparison[r['style']]['outputSha256']
    coverage['adoption']={'version':'type-common-2.2-optical2-candidate','scope':'Only 复 glyph and name IDs3/5 differ from 2.1; all metrics/cmap/order/other glyph bytes unchanged','status':'candidate; not production adopted'}
    coverage['opticalCorrections']={'source':'source-snapshot.zip','findings':['FL-01'],'previousCorrectionsRetained':['MIGRATION-FONT-001','MIGRATION-FONT-002'],'unchangedGlyphs':9701,'metricsUnchanged':True}
    write(out/'coverage.json',coverage)
    write(out/'environment.json',{'python':sys.version,'packages':{n:importlib.metadata.version(n)for n in ['fonttools','skia-pathops','brotli']},'command':sys.argv})
    print(json.dumps({'out':str(out),'changed':['复'],'comparison':comparison},ensure_ascii=False))
if __name__=='__main__':main()
