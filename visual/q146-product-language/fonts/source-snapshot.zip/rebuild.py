"""Versioned, single-glyph optical correction; all other outlines/metrics must stay exact."""
from pathlib import Path
import sys,json,hashlib,shutil
from fontTools.ttLib import TTFont
from fontTools.pens.ttGlyphPen import TTGlyphPen
import argparse
source_root=Path(__file__).resolve().parent
sys.path.insert(0,str(source_root/'compiler'))
from product_fonts import median_lines,optical_widths,ribbon_union
from hanzi_contacts import restore_contacts
parser=argparse.ArgumentParser();parser.add_argument('--out',required=True,type=Path);run=parser.parse_args().out.resolve()
if run.exists():raise SystemExit('Choose a new output directory')
run.mkdir(parents=True)
source=source_root/'glyphs-used.json'
row=json.loads(source.read_text())['glyphs']['图']
original=json.loads(json.dumps(row))
# The terminal belongs to 内冬, not the outside enclosure. Preserve a visible
# white channel and its descending diagonal; do not restore this source contact.
row['medians'][4]=row['medians'][4][:4]+[[710,330]]
row['contacts']=[p for p in row['contacts'] if p!=[1,4]]
(run/'optical-override.json').write_text(json.dumps({'character':'图','upstreamGlyph':original,'opticalGlyph':row,'reason':'MIGRATION-FONT-001: separate inner diagonal from right enclosure; preserve inner joins'},ensure_ascii=False,indent=2)+'\n')
lines=median_lines(row['medians'])
widths=[optical_widths(lines,base,style)for style,base in [('Text',6.6),('Display',7.8)]]
lines,report=restore_contacts(lines,row['contacts'],ribbon_union,widths,grid_pairs=row['gridContacts'])
(run/'contact-result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
assert not report['unresolved']
(run/'fonts').mkdir(exist_ok=True)
comparison={}
for style,width in zip(['Text','Display'],widths):
 p=source_root/'input-fonts'/f'SGGPaperUI-{style}.woff2'
 font=TTFont(p,recalcTimestamp=False)
 cmap=font.getBestCmap();old={cp:font['glyf'][name].compile(font['glyf']) for cp,name in cmap.items()}
 metrics=dict(font['hmtx'].metrics)
 pen=TTGlyphPen(None);ribbon_union(lines,width).draw(pen);glyph=pen.glyph();font['glyf'][cmap[ord('图')]]=glyph
 # Keep the proven advance and sidebearing; only the inner terminal changed.
 for key,value in {3:f'SGG Paper UI-{style}-product-2.1',5:'Version 2.100; common Hanzi optical correction 1'}.items():
  font['name'].names=[n for n in font['name'].names if n.nameID!=key]
  font['name'].setName(value,key,3,1,0x409)
 target=run/'fonts'/p.name;font.save(target);out=TTFont(target)
 changed=[chr(cp) for cp,name in out.getBestCmap().items() if out['glyf'][name].compile(out['glyf'])!=old[cp]]
 assert changed==['图'],changed
 assert out['hmtx'].metrics==metrics
 assert len(out.getBestCmap())==9702
 assert 'COLR'not in out and 'CPAL'not in out
 comparison[style]={'changedGlyphs':changed,'metricsUnchanged':True,'cmap':len(out.getBestCmap()),'before':hashlib.sha256(p.read_bytes()).hexdigest(),'after':hashlib.sha256(target.read_bytes()).hexdigest()}
(run/'comparison.json').write_text(json.dumps(comparison,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(comparison,ensure_ascii=False))
